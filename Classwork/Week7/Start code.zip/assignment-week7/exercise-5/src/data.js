/* Your data here */
export const Data = [
  {
    name: "Chaewon",
    classroom: "Class A",
    gender: "female",
    src: "https://www.j-14.com/wp-content/uploads/2023/09/chaewon-le-sserafim-.jpg?fit=4666%2C3111&quality=86&strip=all",
  },
  {
    name: "Eunchae",
    classroom: "Class B",
    gender: "female",
    src: "https://external-preview.redd.it/le-sserafims-hong-eunchae-to-sit-out-this-weeks-music-bank-v0-MyGCgwGC87UtC2Vp_dWwrTRK4_WY0uGPOKU_wSMhzOA.jpg?auto=webp&s=a1889a869343d0ba6f4d1e398087c2a4cc4e7410",
  },
  {
    name: "Kazuha",
    classroom: "Class C",
    gender: "female",
    src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS4MEd4kjJCixAeOcJjgeTlPYODCbEmEwuk4w&s",
  },
  {
    name: "Sakura",
    classroom: "Class D",
    gender: "female",
    src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWZS4dtZyD5mE5N4Z-4mKl8o5-mX8nTFmLhw&s",
  },
  {
    name: "Yunjin",
    classroom: "Class E",
    gender: "female",
    src: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6WXfR6NVOb5vjEwAlcIEUjMHm0R-mMRZABw&s",
  },
];
